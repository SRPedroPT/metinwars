<?php
	//Site url - add / at the end, eg: http://metin2cms.cf/mt2/ IMPORTANT!!!
	$site_url = "http://metin2cms.cf/mt2/";
	
	//Game database
	$host = "localhost";
	$user = "root";
	$password = "xxxxxx";
	
	//Mail settings
	$SMTPAuth = true;
	$SMTPSecure = "ssl";
	$EmailHost = "smtp.gmail.com";
	$emailPort = 465;
	
	$email_username = "metin2cms.cf@gmail.com";//gmail account
	$email_password = "xxxxxx";//gmail password
	
	//Register
	$safebox_size = 1;